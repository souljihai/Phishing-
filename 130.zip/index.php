<?php
header("Location: ./130/");
exit();
?>